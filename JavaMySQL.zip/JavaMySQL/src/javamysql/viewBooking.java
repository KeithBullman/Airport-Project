
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.*;

public class viewBooking {
    public static void Print(String username){
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            String depart = "";
            String arrive = "";
            String bookId = "";
            
            Statement findBookId = con.createStatement();
            String findId = "SELECT bookId FROM booking WHERE clientUsername = '" + username + "'";     
            ResultSet fId = findBookId.executeQuery(findId);
            
            while(fId.next()){
                bookId = fId.getString("bookId");
            }
            
            Statement findDepartId = con.createStatement();
            String findDepart = "SELECT flightDepart FROM flight WHERE flightId = (SELECT flightId FROM booking WHERE bookId = '" + bookId + "')";
            ResultSet fd = findDepartId.executeQuery(findDepart);
            
            while(fd.next()){
                depart = fd.getString("flightDepart");
            }
            
            Statement findArriveId = con.createStatement();
            String findArrive = "SELECT flightArrive FROM flight WHERE flightId = (SELECT flightId FROM booking WHERE bookId = '" + bookId + "')";
            ResultSet fa = findArriveId.executeQuery(findArrive);
            
            while(fa.next()){
                arrive = fa.getString("flightArrive");
            }
            
            System.out.println("Booking for " + username);
            System.out.println("Booking ID: " + bookId);
            System.out.println("Departing: " + depart);
            System.out.println("Arriving In: " + arrive);
            
        }
        catch(SQLException e){
            
        }
    }
    
}
