    
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.util.Scanner;

public class RunDB {
    
    /** Creates a new instance of RunDB */
    public RunDB() {
    }
    
    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        
        try {

        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("=====AIRPORT======\n");
        System.out.print("Login as:\nUser (1)\nAdmin (2)\nCreate User (3) \nQuit (4)");

        System.out.print("\nLogin Decision: ");
        int decision = keyboard.nextInt();
        keyboard.nextLine();
        
            switch(decision){

                case 1:

                    System.out.print("Enter email: ");
                    String email = keyboard.nextLine();
                    System.out.print("Enter password: ");
                    String password = keyboard.nextLine();

                    clientSignIn.SignIn(email, password);
                    
                    if(clientSignIn.SignIn(email, password) == true){
                        System.out.println("Welcome!\n------");
                    }
                    else{
                        System.out.println("Incorrect Name or Password!\n");
                        break;
                    }
                    
                    while (true){
                        
                        int choice = clientDecision.choice();
                        
                        //View Flights
                        if (choice == 1){
                            viewFlights.Print();
                        }
                        
                        //Create Booking
                        else if (choice == 2){
                            viewFlights.Print();
                            System.out.print("Enter your username: ");
                            String bookName = keyboard.nextLine();
                            System.out.print("Which flight? (Number): ");
                            int flightChoice = keyboard.nextInt();
                            keyboard.nextLine();
                            createBooking.Create(flightChoice, bookName);
                        }
                        
                        else if (choice == 3){
                            System.out.print("Enter username: ");
                            String viewUsername = keyboard.nextLine();
                            viewBooking.Print(viewUsername);
                        }
                        
                        //Cancel Booking
                        else if (choice == 4){
                            System.out.print("Enter Username: ");
                            String bookUsername = keyboard.nextLine();
                            System.out.print("Enter Booking Id: ");
                            String bookId = keyboard.nextLine();
                            cancelBooking.Cancel(bookUsername, bookId);

                        }
                        
                        //Update Account Settings
                        else if (choice == 5){
                            System.out.print("Enter Old Username: ");
                            String oldUsername = keyboard.nextLine();
                            
                            System.out.print("New Username: ");
                            String userName = keyboard.nextLine();
                            
                            System.out.print("New First Name: ");
                            String fName = keyboard.nextLine();
                            
                            System.out.print("New Last Name: ");
                            String lName = keyboard.nextLine();
                            
                            System.out.print("New Email: ");
                            String newEmail = keyboard.nextLine();
                            
                            System.out.print("New Phone No:");
                            int phone = keyboard.nextInt();
                            keyboard.nextLine();
                            
                            updateClient.Update(userName, fName, lName, newEmail, phone, oldUsername);
                            
                        }
                        
                        //Break
                        else{
                            break;
                        }
                        
                    }
                    
                    break;

                case 2:

                    System.out.print("Enter Username: ");
                    String adminName = keyboard.next();
                    System.out.print("Enter Password: ");
                    String adminPassword = keyboard.next();

                    adminSignIn.SignIn(adminName, adminPassword);
                    
                    if(adminSignIn.SignIn(adminName, adminPassword) == true){
                        System.out.println("Welcome " + adminName + "!\n------");
                    }
                    else{
                        System.out.println("Incorrect Name or Password!\n");
                        break;
                    }
                    
                    while (true){
                        
                        int choice = adminDecision.choice();
                        keyboard.nextLine();
                        
                        //Create Country
                        if(choice == 1){
                            System.out.print("\nCountry: ");
                            String country = keyboard.nextLine();
                            
                            System.out.print("\nCountry ID: ");
                            String countryId = keyboard.nextLine();
                            
                            createCountry.Create(countryId, country);
                        }
                        
                        //Create Airport
                        else if(choice == 2){
                            System.out.print("\nAirport ID: ");
                            String airportId = keyboard.nextLine();
                            
                            System.out.print("\nAirport Name: ");
                            String name = keyboard.nextLine();
                            
                            System.out.print("\nCity Name: ");
                            String city = keyboard.nextLine();
                            
                            System.out.print("\nCountry: ");
                            String country = keyboard.nextLine();
                            
                            createAirport.Create(airportId, name, city, country);
                        }
                        
                        //Add Airline
                        else if(choice == 3){
                            System.out.print("Airline: ");
                            String airline = keyboard.nextLine();
                            
                            System.out.print("Plane Type: ");
                            String type = keyboard.nextLine();
                            
                            System.out.print("Capacity: ");
                            int capacity = keyboard.nextInt();
                            keyboard.nextLine();
                            
                            createPlane.Create(airline, type, capacity);
                        }
                        
                        
                        //Create Flight
                        else if(choice == 4){
                            createFlight.printAirlines();
                            System.out.print("\nAirline: ");
                            String airline = keyboard.nextLine();
                            
                            createFlight.printDeparture();
                            System.out.print("\nDepart which Airport: ");
                            String departAirport = keyboard.nextLine();
                            
                            createFlight.printArrival(departAirport);
                            System.out.print("\nArrival at which Airport: ");
                            String arriveAirport = keyboard.nextLine();        
                            
                            System.out.print("\nTime of Flight: ");
                            String time = keyboard.nextLine();
                            
                            createFlight.Create(airline, departAirport, arriveAirport, time);
                        }
                        
                        //View Customer Details
                        else if (choice == 5){
                            System.out.print("Enter Username to View Details: ");
                            String userName = keyboard.nextLine();
                            viewDetails.User(userName);
                        }
                        
                        
                        //Break
                        else{
                            System.out.print("LOGGING OUT\n");
                            break;
                        }
                    }
                    
                    break;
                
                case 3:
                    
                    System.out.print("Enter Username: ");
                    String userName = keyboard.nextLine();

                    System.out.print("Enter First Name: ");
                    String firstName = keyboard.nextLine();

                    System.out.print("Enter Last Name: ");
                    String lastName = keyboard.nextLine();

                    System.out.print("Enter Email: ");
                    String userEmail = keyboard.nextLine();

                    System.out.print("Enter Phone No: ");
                    int phoneNo = keyboard.nextInt();
                    keyboard.nextLine();

                    System.out.print("Enter Password: ");
                    String userPassword = keyboard.nextLine();

                    createClient.Create(userName, firstName, lastName, userEmail, phoneNo, userPassword);
                    break;

            }
        }
        
        catch(Exception ex){
            System.out.println("SQLException: " + ex.getMessage());
        }
    }
}