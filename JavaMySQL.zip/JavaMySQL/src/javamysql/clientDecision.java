
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class clientDecision {
    
    public static int choice(){
        Scanner keyboard = new Scanner(System.in);
        System.out.print("\nSearch Flights (1)\nFlight Booking (2)\nView Booking (3)\nCancel Booking (4)\nUpdate Account Settings (5)\nQuit (6)");
        System.out.print("\nDecision: ");
        int decision = keyboard.nextInt();
        keyboard.nextLine();
        return decision;
    }   
}
