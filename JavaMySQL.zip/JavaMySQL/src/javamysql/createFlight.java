
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class createFlight {
    
    public static void printAirlines(){
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );    

            Statement stmt = con.createStatement();
            String airlines = "SELECT planeCompany FROM plane";
            ResultSet al = stmt.executeQuery(airlines);
        
            System.out.println("Available Airlines:\n");  
            while(al.next()) { 
                System.out.print(al.getString("planeCompany"));
                System.out.print("\n");
            }
        }
        catch(SQLException e){
                
        }
    }
    
    
    public static void printDeparture(){
        try{
        
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();
            
            String airports = "SELECT name FROM airport";
            ResultSet ap = stmt.executeQuery(airports);
        
            System.out.println("Available Airports for Departure:\n");  
            while(ap.next()) { 
                System.out.print(ap.getString("name"));
                System.out.print("\n");
            }
        }
        
        catch(SQLException e){
            
        }
    }
    
    public static void printArrival(String departingAirport){
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();
            
            String airports = "SELECT name FROM airport WHERE name != '" + departingAirport + "'";
            ResultSet ap = stmt.executeQuery(airports);
        
            System.out.println("\nAvailable Airports for Arrival:\n");  
            while(ap.next()) { 
                System.out.print(ap.getString("name"));
                System.out.print("\n");
            }
            
        }
        catch(SQLException e){
            
        }
    }
    
    public static void Create(String airline, String depart, String arrive, String time){
        try{
            
            String departCode = "";
            String arriveCode = "";
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();
            
            Statement departure = con.createStatement();
            String findDepartCode = "SELECT airportId FROM airport WHERE name = '" + depart + "'";
            ResultSet dc = departure.executeQuery(findDepartCode);
         
            while(dc.next()) { 
                departCode = dc.getString("airportId");
            }
            
            Statement arrival = con.createStatement();
            String findArriveCode = "SELECT airportId FROM airport WHERE name = '" + arrive + "'";
            ResultSet ac = arrival.executeQuery(findArriveCode);
         
            while(ac.next()) { 
                arriveCode = ac.getString("airportId");
            }
            
            
            String create = "INSERT INTO flight (planeCompany, flightDepart, flightTime, flightArrive) VALUES ('" + airline + "', '" + departCode + "', '" + time + "', '" + arriveCode + "')";
            int res = stmt.executeUpdate(create);
            System.out.print("Flight Entry Successful!\n");
            
        }
        catch(SQLException e){
            
        }
    }
}
