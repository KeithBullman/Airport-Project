
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class updateClient {

    public static void Update(String username, String firstName, String lastName, String email, int phone, String oldUsername){
            try {
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );

            Statement updateStmt = con.createStatement();
            String updateSQL = "Update client SET clientUsername = '" + username + "', fName = '" + firstName + "', lName = '" + lastName + "', email = '" + email + "', phone = '" + phone + "' WHERE clientUsername = '" + oldUsername + "'"; ;
            int res = updateStmt.executeUpdate(updateSQL);
            System.out.println("Client Record Updated!");
            updateStmt.close();
            }
            catch (Exception io) {
       };  
    }
}
