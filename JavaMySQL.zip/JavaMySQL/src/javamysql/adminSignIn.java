
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class adminSignIn {
    
    public static boolean SignIn(String username, String password){
        boolean success = false;
        
        try{
            
            String name = "";
            String adminPassword = "";
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
                
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM admin WHERE adminUsername='" + username + "' && password='" + password + "'";
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                name = rs.getString("adminUsername");
                adminPassword = rs.getString("password");
            }

            if(name.equals(username) && adminPassword.equals(password)) {
                success = true;
            } 
            else {
                success = false;
            }
        }
        
        catch(SQLException e){
            
        }
        return success;
    }
}
