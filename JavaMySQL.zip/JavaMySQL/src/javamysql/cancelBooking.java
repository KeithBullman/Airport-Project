
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.*;

public class cancelBooking {
    public static void Cancel(String username, String bookId){
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            
            String name = "";
            String id = "";
                
            Statement stmt = con.createStatement();
            String SQL = "SELECT clientUsername, bookId FROM booking WHERE clientUsername='" + username + "' && bookId='" + bookId + "'";
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                name = rs.getString("clientUsername");
                id = rs.getString("bookId");
            }
            
            if(name.equals(username) && id.equals(bookId)) {
                Statement deleteStmt = con.createStatement();
                String deleteSQL = "DELETE FROM booking WHERE clientUsername = '" + username + "' AND bookId = '" + bookId + "'";
                int res = deleteStmt.executeUpdate(deleteSQL);
                System.out.print("Booking cancelled for " + username + "\n");
            } 
            else {
                System.out.print("Name and BookId Not Currently Logged In System!\n");
            }   
        }
        catch(SQLException e){

        }
    }
}
