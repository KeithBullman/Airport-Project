
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.*;

public class viewFlights {
    public static void Print(){
        try{
            
            ArrayList<String> departList = new ArrayList<String>();
            ArrayList<String> arriveList = new ArrayList<String>();
            ArrayList<String> timeList = new ArrayList<String>();
            
            String depart = "";
            String arrive = "";
            String time = "";
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();

            Statement departure = con.createStatement();          
            String findDeparts = "SELECT name FROM airport WHERE airportId IN (SELECT flightDepart FROM flight)";
            ResultSet fd = departure.executeQuery(findDeparts);
            
            Statement arrival = con.createStatement();
            String findArrivals = "SELECT name FROM airport WHERE airportId IN (SELECT flightArrive FROM flight)";
            ResultSet fa = arrival.executeQuery(findArrivals);
            
            Statement times = con.createStatement();
            String findTimes = "SELECT flightTime FROM flight";
            ResultSet ft = times.executeQuery(findTimes);
            
            while(fd.next()){
                departList.add(fd.getString("name"));
                }
            
            while(fa.next()){
                arriveList.add(fa.getString("name"));
            }
            
            while(ft.next()){
                timeList.add(ft.getString("flightTime"));
            }
            
            //Collections.reverse(arriveList);
            
            for (int counter = 0; counter < departList.size(); counter++) { 		      
                      System.out.println("\n" + (counter+1) + ": " + departList.get(counter) + " >>> " + arriveList.get(counter) + " @ " + timeList.get(counter) + "\n"); 		
                  }   		

        }
        catch(SQLException e){

        }
    }
}
