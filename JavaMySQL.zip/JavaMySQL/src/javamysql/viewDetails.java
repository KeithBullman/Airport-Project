
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class viewDetails {
    
    public static void User(String username){
        try{
            
            String firstName = "";
            String lastName = "";
            String email = "";
            int phone = 0;
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();
            
            Statement departure = con.createStatement();
            String findDepartCode = "SELECT fName, lName, email, phone FROM client WHERE clientUsername = '" + username + "'";
            ResultSet rs = departure.executeQuery(findDepartCode);
         
            while(rs.next()) { 
                firstName = rs.getString("fName");
                lastName = rs.getString("lName");
                email = rs.getString("email");
                phone = rs.getInt("phone");
            }
            System.out.print("\nDetails for " + username + "\n");
            System.out.print("Name: " + firstName + " " + lastName + "\nEmail: " + email + "\nPhone No: " + phone + "\n");
        }
        catch(SQLException e){
            
        }
    }
}
