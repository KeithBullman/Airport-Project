
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class clientSignIn {
    
    public static boolean SignIn(String email, String userPassword){
        boolean success = false;
        
        try{
            
            String name = "";
            String password = "";
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
     
            Statement userStatement = con.createStatement();
            String userSQL = "SELECT * FROM client WHERE email='" + email + "' && password='" + userPassword + "'";
            ResultSet userRS = userStatement.executeQuery(userSQL);
                   
            while (userRS.next()){
            name = userRS.getString("email");
            password = userRS.getString("password");
            }

            if(name.equals(email) && password.equals(userPassword)) {
                success = true;
            }

            else {
                success = false;
            }
        }

        catch(SQLException e){
                
        }
        return success;
    }     
}
