
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class adminDecision {

    public static int choice(){
        Scanner keyboard = new Scanner(System.in);
        System.out.print("\nAdd Country (1)\nAdd Airport (2)\nAdd Airline (3)\nAdd Flight (4)\nView Customer Details (5)\nQuit (6)");
        System.out.print("\nDecision: ");
        int decision = keyboard.nextInt();
        keyboard.nextLine();
        return decision;
        
    }
}
