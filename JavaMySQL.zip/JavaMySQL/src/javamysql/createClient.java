
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class createClient {
    
    public static void Create(String username, String fName, String lName, String email, int phone, String password){
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement insertStmt = con.createStatement();
            String insertSQL = " INSERT INTO client VALUES ('" + username + "', '" + fName + "', '" + lName + "', '" + email + "', '" + phone + "', '" + password + "')";
            int res = insertStmt.executeUpdate(insertSQL);
            System.out.print("Client Entry Successful!\n");
            
        }
        catch(SQLException e){
            
        }
    }
}
