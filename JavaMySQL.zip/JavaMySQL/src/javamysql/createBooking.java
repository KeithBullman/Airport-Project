
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.*;

public class createBooking {
    public static void Create(int choice, String username){
        try{
            
            ArrayList<String> departList = new ArrayList<String>();
            ArrayList<String> arriveList = new ArrayList<String>();
            
            String depart = "";
            String arrive = "";
            String time = "";
            
            String flightId = "";
            String airportId = "";
            
            Random rand = new Random();
            int seatId = rand.nextInt(150);
            
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement stmt = con.createStatement();

            Statement departure = con.createStatement();          
            String findDeparts = "SELECT name FROM airport WHERE airportId IN (SELECT flightDepart FROM flight)";
            ResultSet fd = departure.executeQuery(findDeparts);
            
            Statement arrival = con.createStatement();
            String findArrivals = "SELECT name FROM airport WHERE airportId IN (SELECT flightArrive FROM flight)";
            ResultSet fa = arrival.executeQuery(findArrivals);
            
            while(fd.next()){
                departList.add(fd.getString("name"));
                }
            
            while(fa.next()){
                arriveList.add(fa.getString("name"));
            }
            
            //Collections.reverse(arriveList);
            
            Statement findFlightId = con.createStatement();
            String flightIdFind = "SELECT flightId FROM flight WHERE flightDepart = (SELECT airportId FROM airport WHERE name = '" + departList.get(choice-1) + "')";
            ResultSet fId = findFlightId.executeQuery(flightIdFind);
            
            Statement findAirportId = con.createStatement();
            String airportIdFind = "SELECT airportId from airport WHERE name = '" + departList.get(choice-1) + "'";
            ResultSet faId = findAirportId.executeQuery(airportIdFind);
            
            while(fId.next()){
                flightId = fId.getString("flightId");
            }
            
            
            while(faId.next()){
                airportId = faId.getString("airportId");
            }
            
            Statement book = con.createStatement();
            String create = "INSERT INTO booking (clientUsername, flightId, seatId, airportId) VALUES ('" + username + "', '" + flightId + "', '" + seatId + "', '" + airportId + "')";
            int res = book.executeUpdate(create);
            System.out.print("Flight Entry Successful!\n");
            
            
            
            
//            Statement book = con.createStatement();
//            String booking = "INSERT INTO booking (clientUsername, flightId, seatId, airportId) VALUES '(" + username + "', '" + flightId + "', '" + seatId + "', '" + airportId + "')";
//            int createBooking = book.executeUpdate(booking);
//            System.out.print("Booking Entry Created!\n");
                    
        }
        catch(SQLException e){
            
        }
    }
}
