
/**
 * Name: Keith Bullman
 * ID: R00178736
 * Class: SDH2-A
 */

package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class createPlane {
    
    public static void Create(String airline, String type, int capacity){
        try{   
        
            Connection con = DriverManager.getConnection("jdbc:mysql://157.190.43.7:3306/r00178736_flightsystem?useSSL=false&user=R00178736&password=Autumn2019" );
            
            Statement insertStmt = con.createStatement();
            String insertSQL = " INSERT INTO plane VALUES ('" + airline + "', '" + type + "', '" + capacity +"')";
            int res = insertStmt.executeUpdate(insertSQL);
            System.out.print("Plane Entry Successful!\n");
            
        }
        catch(SQLException e){
            
        }
    }
}
